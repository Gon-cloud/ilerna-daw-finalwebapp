<?php

//Declarar variable 

$place = ""; //Lugar
$country_region= "";//Pais o Region

// Comprobar que el usuario ha iniciado sesión
if (isset($_POST['clockin_button']) && $_POST["enviado"] == "1") {

    //Enviar mensaje de exito 
    //
    if (isset($place) && isset($_POST['clockin_button']) && $_POST["enviado"] == "1") {
        $mensaje = new Message('exito', 'Ha fichado con éxito');
        echo $mensaje->show();}

    // Obtener los datos enviados por el formulario
    $country_region = $_POST['country_region'];
    $place = $_POST['place'];
    $location = $_POST['location'];
    $date = date('Y-m-d H:i:s');

    // Ejecutar la consulta SQL
    $resultado = mysqli_query($con, "INSERT INTO clockins VALUES ('', '$user_email', '$date',  '$country_region', '$place', '$location')");

    // Comprobar si se ha insertado correctamente
    if ($resultado) {
         } else {
     echo 'Error al insertar los datos<br>';
    }

    //impedir que se envien mensajes al hacer F5 o al recargar la página
    unset($_POST['enviado']);
    $mensaje = new Message('', '');
    
}
//header("location: index.php"); Prueba solución bug, genera otro bug de duplicados

?>
