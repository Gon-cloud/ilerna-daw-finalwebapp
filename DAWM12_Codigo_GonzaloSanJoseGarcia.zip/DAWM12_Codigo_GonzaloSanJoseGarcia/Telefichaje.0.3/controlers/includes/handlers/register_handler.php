<?php 
//Declarar variables
$fname = ""; //Nombre
$lname = ""; //Apellidos
$em = ""; //email
$em2 = ""; //email bis
$password = ""; //password
$password2 = ""; //password bis
$date = ""; //fecha de creación de cuenta 
$error_array = array(); //Varible para guardar mensajes de error

if(isset($_POST['register_button'])){

	//Registration form values

	//Preparación nombre
	$fname = strip_tags($_POST['reg_fname']); //quitar resto etiqeta html
	$fname = str_replace(' ', '', $fname); //quitar espacios
	$fname = ucfirst(strtolower($fname)); //poner en formato frase, todo minuscula menos la primera letra 
	$_SESSION['reg_fname'] = $fname; //Almacenar la varible como variable de sesión

	//Preparación apellidos
	$lname = strip_tags($_POST['reg_lname']); //quitar resto etiqeta html
	$lname = str_replace(' ', '', $lname); //quitar espacios
	$lname = ucfirst(strtolower($lname)); //poner en formato frase, todo minuscula menos la primera letra
	$_SESSION['reg_lname'] = $lname; //Almacenar la varible como variable de sesión

	//Preparación email
	$em = strip_tags($_POST['reg_email']); //quitar resto etiqeta html
	$em = str_replace(' ', '', $em); //quitar espacios
	$em = ucfirst(strtolower($em)); //poner en formato frase, todo minuscula menos la primera letra
	$_SESSION['reg_email'] = $em; //Almacenar la varible como variable de sesión

	//Preparación email 2
	$em2 = strip_tags($_POST['reg_email2']); //quitar resto etiqeta html
	$em2 = str_replace(' ', '', $em2); //quitar espacios
	$em2 = ucfirst(strtolower($em2)); //poner en formato frase, todo minuscula menos la primera letra
	$_SESSION['reg_email2'] = $em2; //Almacenar la varible como variable de sesión

	//Preparación Password
	$password = strip_tags($_POST['reg_password']); //quitar resto etiqeta html
	$password2 = strip_tags($_POST['reg_password2']); //quitar resto etiqeta html

	$date = date("Y-m-d"); //fecha actual

	if($em == $em2) {
		//Comprobar el formato de email que es valido para ello se usa la función PHP filter_var con FILTER_VALIDATE_EMAIL 
		if(filter_var($em, FILTER_VALIDATE_EMAIL)) {

			$em = filter_var($em, FILTER_VALIDATE_EMAIL);

			//Comprobar que el email no este repetido
			$e_check = mysqli_query($con, "SELECT email FROM users WHERE email='$em'");

			//Contar resultado de filas de query anterior
			$num_rows = mysqli_num_rows($e_check);

			if($num_rows > 0) {
				array_push($error_array, "Email already in use<br>");
			}

		}
		else {
			array_push($error_array, "Invalid email format<br>");
		}


	}
	else {
		array_push($error_array, "Emails don't match<br>");
	}


	if(strlen($fname) > 25 || strlen($fname) < 2) {
		array_push($error_array, "Your first name must be between 2 and 25 characters<br>");
	}

	if(strlen($lname) > 25 || strlen($lname) < 2) {
		array_push($error_array,  "Your last name must be between 2 and 25 characters<br>");
	}

	if($password != $password2) {
		array_push($error_array,  "Your passwords do not match<br>");
	}
	else {
		if(preg_match('/[^A-Za-z0-9]/', $password)) {
			array_push($error_array, "Your password can only contain english characters or numbers<br>");
		}
	}

	if(strlen($password) > 30 || strlen($password) < 5) {
		array_push($error_array, "Your password must be betwen 5 and 30 characters<br>");
	}


	if(empty($error_array)) {
		$password = md5($password); //Función que encripta la contraseña antes de mandarla a base de datos

		//Crear username concatenando nombre y apellidos
		$username = strtolower($fname . "_" . $lname);
		$check_username_query = mysqli_query($con, "SELECT username FROM users WHERE username='$username'");


		$i = 0; 
		//Si ya existe añade un número al username
		while(mysqli_num_rows($check_username_query) != 0) {
			$i++; //Añade el paso al contador
			$username = $username . "_" . $i;
			$check_username_query = mysqli_query($con, "SELECT username FROM users WHERE username='$username'");
		}

		//Asignación de foto de perfil aleatoria
		$rand = rand(1, 8); //Numero aleatorio entre 1 y 6.

		if($rand == 1)
			$profile_pic = "../additional_resources/images/profile_pics/defaults/head_deep_blue.png";
		else if($rand == 2)
			$profile_pic = "../additional_resources/images/profile_pics/defaults/head_emerald.png";
		else if($rand == 3)
			$profile_pic = "../additional_resources/images/profile_pics/defaults/head_alizarin.png";
		else if($rand == 4)
			$profile_pic = "../additional_resources/images/profile_pics/defaults/head_amethyst.png";
		else if($rand == 5)
			$profile_pic = "../additional_resources/images/profile_pics/defaults/head_carrot.png";
		else if($rand == 6)
			$profile_pic = "../additional_resources/images/profile_pics/defaults/head_green_sea.png";
		else if($rand == 7)
			$profile_pic = "../additional_resources/images/profile_pics/defaults/head_sun_flower.png";
		else if($rand == 8)
			$profile_pic = "../additional_resources/images/profile_pics/defaults/head_wet_asphalt.png";


		$query = mysqli_query($con, "INSERT INTO users VALUES ('', '$fname', '$lname', '$username', '$em', '$password', '$date', '$profile_pic', '0', '0', 'no', ',')");

		array_push($error_array, "<span style='color: #14C800;'>You're all set! Go ahead and login!</span><br>");

		//Limpiar variables de sesión. Prevenir Cacheo de dato.
		$_SESSION['reg_fname'] = "";
		$_SESSION['reg_lname'] = "";
		$_SESSION['reg_email'] = "";
		$_SESSION['reg_email2'] = "";
	}

}
?>