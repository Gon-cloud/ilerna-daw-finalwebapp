<?php 

include("../../../views/config/config.php");
include("../classes/User.php");
include("../classes/Post.php");

$limit = 10; //limite de comentarios (posts) qe carga en cada llamada

$posts = new Post($con, $_REQUEST['userLoggedIn']);
$posts->loadPosts($_REQUEST, $limit);

?>