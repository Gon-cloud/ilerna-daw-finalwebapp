<?php

//Obtener los últimos 30 registros de la tabla clockins para el usuario actual
							
$query_datos_clockins = mysqli_query($con, "SELECT clockin_date, country_region, place, clockin_location FROM clockins WHERE user_email = '$user_email' ORDER BY Id DESC LIMIT 30");
				
$result = mysqli_num_rows($query_datos_clockins);

?>
