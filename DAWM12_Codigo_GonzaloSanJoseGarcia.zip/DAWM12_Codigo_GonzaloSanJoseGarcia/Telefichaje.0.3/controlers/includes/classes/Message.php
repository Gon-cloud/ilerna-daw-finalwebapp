<?php 

class Message {
	
  private $tipo;
  private $mensaje;

  public function __construct($tipo, $mensaje) {
    $this->tipo = $tipo;
    $this->mensaje = $mensaje;
  }

  public function show() {
    echo '<div class="mensaje" id="div-1"' . $this->tipo . '">' . $this->mensaje . '</div>';
  }
}

?>