<?php 

class Post {

	private $user_obj;
	private $con;

	public function __construct($con, $user){
		$this->con = $con;
		$this->user_obj = new User($con, $user);
	}

	public function submitPost($body, $user_to) {
		$body = strip_tags($body); //quitar etiquetas html
		$body = mysqli_real_escape_string($this->con, $body);
		$check_empty = preg_replace('/\s+/', '', $body); //quitar espacios vacios
      
		if($check_empty != "") {

			//timestamp actual
			$date_added = date("Y-m-d H:i:s");
			//Registra variable usuario
			$added_by = $this->user_obj->getUsername();

			//Comprueba si el usuario esta en su cuenta, en caso contrario la variable user_to is 'none'
			if($user_to == $added_by) {
				$user_to = "none";
			}

			//inserta comentario 
			$query = mysqli_query($this->con, "INSERT INTO posts VALUES('', '$body', '$added_by', '$user_to', '$date_added', 'no', 'no', '0')");
			$returned_id = mysqli_insert_id($this->con);
 
			//actualiza la fecha de creación comentario
			$num_posts = $this->user_obj->getNumPosts();
			$num_posts++;
			$update_query = mysqli_query($this->con, "UPDATE users SET num_posts='$num_posts' WHERE username='$added_by'");

		}
	}

	public function loadPosts($data, $limit) {

		$page = $data['page']; 
		$userLoggedIn = $this->user_obj->getUsername();

		if($page == 1) 
			$start = 0;
		else 
			$start = ($page - 1) * $limit;


		$str = ""; //Devuelve la cadena 
		$data_query = mysqli_query($this->con, "SELECT * FROM posts WHERE deleted='no' ORDER BY id DESC");

		if(mysqli_num_rows($data_query) > 0) {


			$num_iterations = 0; //Numero de iteraciones comprobadas, que no mostradas
			$count = 1;

			while($row = mysqli_fetch_array($data_query)) {
				$id = $row['id'];
				$body = $row['body'];
				$added_by = $row['added_by'];
				$date_time = $row['date_added'];

				//Prepara la variable user_to incluida incluso no posteado 
					if($row['user_to'] == "none") {
					$user_to = "";
				}
				else {
					$user_to_obj = new User($con, $row['user_to']);
					$user_to_name = $user_to_obj->getFirstAndLastName();
					$user_to = "to <a href='" . $row['user_to'] ."'>" . $user_to_name . "</a>";
				}

				//Comprueba si el usuario que hio el comentario a cerrado su cuenta
				$added_by_obj = new User($this->con, $added_by);
				if($added_by_obj->isClosed()) {
					continue;
				}

				

					if($num_iterations++ < $start)
						continue; 


					//break, cada vez que alcance el limite de comentarios a cargar 
					if($count > $limit) {
						break;
					}
					else {
						$count++;
					}

					$user_details_query = mysqli_query($this->con, "SELECT first_name, last_name, profile_pic FROM users WHERE username='$added_by'");
					$user_row = mysqli_fetch_array($user_details_query);
					$first_name = $user_row['first_name'];
					$last_name = $user_row['last_name'];
					$profile_pic = $user_row['profile_pic'];


					//Marca de paso de tiempo desde la creación del comentario
					$date_time_now = date("Y-m-d H:i:s");
					$start_date = new DateTime($date_time); //Fecha de creación 
					$end_date = new DateTime($date_time_now); //Fecha actual 
					$interval = $start_date->diff($end_date); //Diferencia entre las dos fechas
					if($interval->y >= 1) {
						if($interval == 1)
							$time_message = " hace " . $interval->y . " año"; //hace un año
						else 
							$time_message = " hace " . $interval->y . " años"; //más de un año
					}
					else if ($interval-> m >= 1) {
						if($interval->d == 0) {
							
						}
						else if($interval->d == 1) {
							$days = " hace " . $interval->d . " día";
						}
						else {
							$days = " hace ". $interval->d . " días ";
						}


						if($interval->m == 1) {
							$time_message = " hace ". $interval->m . " mes" ;
						} 
						else {
							$time_message = " hace " . $interval->m . " meses";
						}

					}
					else if($interval->d >= 1) {
						if($interval->d == 1) {
							$time_message = " Ayer ";
						}
						else {
							$time_message = $interval->d . " hace días";
						}
					}
					else if($interval->h >= 1) {
						if($interval->h == 1) {
							$time_message = $interval->h . " hace una hora";
						}
						else {
							$time_message = $interval->h . " hace horas";
						}
					}
					else if($interval->i >= 1) {
						if($interval->i == 1) {
							$time_message = $interval->i . " hace un minuto";
						}
						else {
							$time_message = $interval->i . " hace unos  minutos";
						}
					}
					else {
						if($interval->s < 30) {
							$time_message = " Ahora mismo ";
						}
						else {
							$time_message = $interval->s . " hace unos segundos";
						}
					}

					$str .= "<div class='status_post'>
								<div class='post_profile_pic'>
									<img src='$profile_pic' width='50'>
								</div>

								<div class='posted_by' style='color:#ACACAC;'>
									<a href='$added_by'> $first_name $last_name </a> $user_to &nbsp;&nbsp;&nbsp;&nbsp;$time_message
								</div>
								<div id='post_body'>
									$body
									<br>
								</div>

							</div>
							<hr>";
				

			} //End bucle while 

			if($count > $limit) 
				$str .= "<input type='hidden' class='nextPage' value='" . ($page + 1) . "'>
							<input type='hidden' class='noMorePosts' value='false'>";
			else 
				$str .= "<input type='hidden' class='noMorePosts' value='true'><p style='text-align: centre;'>No hay más comentarios para mostrar! </p>";
		}

		echo $str;

	}

}

?>